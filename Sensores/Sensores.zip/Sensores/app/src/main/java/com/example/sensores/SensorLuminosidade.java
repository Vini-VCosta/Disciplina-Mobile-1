package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SensorLuminosidade extends AppCompatActivity {
    private TextView lum;
    private SensorManager sm;
    private SensorEventListener listener;
    private Sensor luz;
    private Button btnAce, btnVoltar2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lum = findViewById(R.id.lum);
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        luz = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
        btnAce = findViewById(R.id.btnAce);
        btnVoltar2 = findViewById(R.id.btnVoltar2);

        btnAce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abriAcele();
            }
        });

        btnVoltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar2();
            }
        });

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event)
            {
                lum.setText(String.valueOf(event.values[0]));
                int grayShade = (int) event.values[0];

                if(grayShade > 255) grayShade = 255;

                lum.setTextColor(Color.rgb( 255 - grayShade, 255 - grayShade, 255 - grayShade ) );
                lum.setBackgroundColor(Color.rgb(grayShade,grayShade,grayShade));

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i)
            {

            }
        };

        sm.registerListener(listener,luz,SensorManager.SENSOR_DELAY_FASTEST);

    }

    public void abrirVoltar2(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    public void abriAcele(){
        Intent janela = new Intent(this, SensorAceleracao.class);
        startActivity(janela);
    }

    @Override
    protected void onPause() {

        sm.unregisterListener(listener,luz);
        super.onPause();
    }
}