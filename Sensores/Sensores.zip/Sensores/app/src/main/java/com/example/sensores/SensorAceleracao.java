package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class SensorAceleracao extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    //Tipo de dado Boleano para alterar a cor
    private boolean isColor = false;
    private TextView respostaB;
    //Tipo de dado que armazena numero longo
    private long ultimaAtualizacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_aceleracao);

        respostaB = findViewById(R.id.respostaB);
        respostaB.setBackgroundColor(Color.GREEN);
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        ultimaAtualizacao = System.currentTimeMillis();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            getAccelerometer(event);
        }
    }

    private void getAccelerometer(SensorEvent event){
        float[] values = event.values;
        //Movimento
        float x = values[0];
        float y = values[1];
        float z = values[2];

        float accelationSquareRoot = (x * x + y + z * z) / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
        long tempoatual = System.currentTimeMillis();

        Toast.makeText(getApplicationContext(), String.valueOf(accelationSquareRoot) + " " + SensorManager.GRAVITY_EARTH, Toast.LENGTH_SHORT).show();

        if (accelationSquareRoot >= 2){
            if(tempoatual - ultimaAtualizacao < 200){
                return;
            }
            ultimaAtualizacao = tempoatual;
            if (isColor){
                respostaB.setBackgroundColor(Color.LTGRAY);
            }else{
                respostaB.setBackgroundColor(Color.DKGRAY);
            }
            isColor =! isColor;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}