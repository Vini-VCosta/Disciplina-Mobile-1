package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

//Declaração da classe implemente com a abstração do SensorEventListener
public class SensorProximidade extends AppCompatActivity implements SensorEventListener {

    private TextView res;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar, btnLuminisidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //Mapiamento de todos os objetos do layout
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        res = findViewById(R.id.lum);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnLuminisidade = findViewById(R.id.btnLuminosidade);

        btnLuminisidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLuminosidade();
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    //Chamado de calbacks, tem a função de definir o comportamento do cliclo de vida das actives
    //OnResume e OnPause
    @Override
    protected void onResume() {
        medir.registerListener(this,proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    protected void onPuse(){
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }

    public void abrirLuminosidade(){
        Intent janela = new Intent(this, SensorLuminosidade.class);
        startActivity(janela);
    }

    public void abrirVoltar(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    //metodo OnSensorChange ocorre quando é exucutado ou modificado algum tipo de evento
    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0){
            getWindow().getDecorView().setBackgroundColor(Color.RED);
            res.setText("Esta Proximo!!!!");
        }else{
            getWindow().getDecorView().setBackgroundColor(Color.BLUE);
            res.setText("Esta longe!!!!");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}