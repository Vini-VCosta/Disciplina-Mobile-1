package com.example.projetofinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class Principal extends AppCompatActivity {

    //Declaração de variaveis
    private Button btnMapa, btnTeaser, btnLink, btnCRUD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        btnMapa = findViewById(R.id.btnMapa);
        btnTeaser = findViewById(R.id.btnTeaser);
        btnLink = findViewById(R.id.btnLink);
        btnCRUD = findViewById(R.id.btnCRUD);

        //Para abrir o mapa menu
        btnMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMapaMenu();
            }
        });

        //Para abrir o teaser
        btnTeaser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeaser();
            }
        });

        //Para abrir o site
        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLink();
            }
        });

        //Para abrir o CRUD
        btnCRUD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirCRUD();
            }
        });
    }

    //Metodo que abre a tela Mapa Menu
    public void abrirMapaMenu(){
        Intent janelaMap = new Intent(this, MapaMenu.class);
        startActivity(janelaMap);
    }

    //Metodo que abre a tela Teaser
    public void abrirTeaser(){
        Intent janelaTea = new Intent(this, Teaser.class);
        startActivity(janelaTea);
    }

    //Metodo que abre o site
    public void abrirLink(){
        Intent janelaLink = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.20thcenturystudios.com/"));
        startActivity(janelaLink);
    }

    //Metodo que abre a tela Cadastrar
    public void abrirCRUD(){
        Intent janelaCRUD = new Intent(this, Cadastrar.class);
        startActivity(janelaCRUD);
    }
}