package com.example.projetofinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class Teaser extends AppCompatActivity {

    //Declaração de variaveis
    private VideoView trailer;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teaser);

        trailer = findViewById(R.id.trailer);
        btnVoltar = findViewById(R.id.btnVoltar);

        //Abre o teaser automaticamente
        Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.teaser);
        trailer.setVideoURI(caminho);
        trailer.start();

        //Volta a tela principal
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });
    }

    //Metodo para voltar a tela principal
    public void abrirVoltar(){
        Intent janela = new Intent(this, Principal.class);
        startActivity(janela);
        trailer.stopPlayback();
    }
}