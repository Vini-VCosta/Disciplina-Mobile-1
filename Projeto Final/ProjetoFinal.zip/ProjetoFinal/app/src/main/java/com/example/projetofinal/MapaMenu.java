package com.example.projetofinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.projetofinal.fragmento.MapaFox;

public class MapaMenu extends AppCompatActivity {

    private Button btnMapaFox, btnVoltar;
    private MapaFox mapaFox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa_menu);

        btnMapaFox = findViewById(R.id.btnMapaFox);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnMapaFox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapaFox = new MapaFox();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, mapaFox);
                transaction.commit();
            }
        });

        //Volta a tela principal
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });
    }

    //Metodo para voltar a tela principal
    public void abrirVoltar(){
        Intent janela = new Intent(this, Principal.class);
        startActivity(janela);
    }
}