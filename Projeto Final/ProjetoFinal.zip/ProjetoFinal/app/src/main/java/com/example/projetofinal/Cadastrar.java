package com.example.projetofinal;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinal.modelo.Usuario;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Cadastrar extends AppCompatActivity {

    //Declaração de variaveis
    EditText editUsuario, editComentario;
    ListView listaDados;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    //Classe Array para vizualizar os usuarios cadastrados
    private List<Usuario> listUsuario = new ArrayList<Usuario>();
    private ArrayAdapter<Usuario> arrayAdapterUsuario;

    //Variavel para selecionar usuario
    Usuario usuarioSelecionado;

    //Botão voltar
    private Button btnVoltar;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);

        editUsuario = findViewById(R.id.editUsuario);
        editComentario = findViewById(R.id.editComentario);
        listaDados = findViewById(R.id.listaDados);
        btnVoltar = findViewById(R.id.btnVoltar);

        inicializarFirebase();
        eventoDataBase();

        //Configuração para voltar
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

        //Procurar o usuario
        listaDados.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                usuarioSelecionado = (Usuario)parent.getItemAtPosition(position);
                editUsuario.setText(usuarioSelecionado.getNome());
                editComentario.setText(usuarioSelecionado.getComentario());
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    //Metodo para voltar para a tela principal
    public void abrirVoltar(){
        Intent janela = new Intent(this, Principal.class);
        startActivity(janela);
    }

    //Metodo usado para buscar os dados dos usuarios na tabela
    private void eventoDataBase() {
        databaseReference.child("Usuario").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listUsuario.clear();
                for (DataSnapshot objSnapshot:snapshot.getChildren()){
                    Usuario user = objSnapshot.getValue(Usuario.class);
                    listUsuario.add(user);
                }
                arrayAdapterUsuario = new ArrayAdapter<>(Cadastrar.this, android.R.layout.simple_list_item_1,listUsuario);
                listaDados.setAdapter(arrayAdapterUsuario);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    //Metodo para iniciar o Firebase
    private void inicializarFirebase() {
        FirebaseApp.initializeApp(Cadastrar.this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseDatabase.setPersistenceEnabled(true);
        databaseReference= firebaseDatabase.getReference();
    }

    //Metodo para abrir o menu
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    //Metodo para quando o usuario apertar qualquer ação do menu
    public boolean onOptionsItemSelected (MenuItem item){
        int id = item.getItemId();

        //If para adicionar dados
        if (id == R.id.menu_adicionar){
            Usuario user = new Usuario();

            user.setId(UUID.randomUUID().toString());
            user.setNome(editUsuario.getText().toString());
            user.setComentario(editComentario.getText().toString());

            databaseReference.child("Usuario").child(user.getId()).setValue(user);
            limparCampos();
        }
        //If para atualizar os dados
        else if(id == R.id.menu_atualizar){
            Usuario user = new Usuario();

            user.setId(usuarioSelecionado.getId());
            user.setNome(editUsuario.getText().toString().trim());
            user.setComentario(editComentario.getText().toString().trim());

            databaseReference.child("Usuario").child(user.getId()).setValue(user);
            limparCampos();
        }//If para deletar os dados
        else if (id == R.id.menu_deletar){
            Usuario user = new Usuario();

            user.setId(usuarioSelecionado.getId());
            databaseReference.child("Usuario").child(user.getId()).removeValue();
        }
        return true;
    }

    //Metodo para limpar os campos apos terminar a ação requisitada
    public void limparCampos(){
        editUsuario.setText("");
        editComentario.setText("");
    }
}