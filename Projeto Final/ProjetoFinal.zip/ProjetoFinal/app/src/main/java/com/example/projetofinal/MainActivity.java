package com.example.projetofinal;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    //Declaração de variaveis
    private Button btnInicio;
    private MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Inicia a musica
        mp = MediaPlayer.create(this, R.raw.abertura);
        mp.start();

        btnInicio = findViewById(R.id.btnInicio);

        //Metodo que leva o usuario para outra tela
        btnInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent janela = new Intent(MainActivity.this,Principal.class);
                startActivity(janela);
                mp.stop();
            }
        });
    }
}