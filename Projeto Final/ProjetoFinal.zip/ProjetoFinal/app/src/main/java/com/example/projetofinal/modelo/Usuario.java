package com.example.projetofinal.modelo;

public class Usuario {

    //Declaração de variaveis
    private String id;
    private String nome;
    private String comentario;

    //Construtor cheio
    public Usuario(String id, String nome, String senha) {
        this.id = id;
        this.nome = nome;
        this.comentario = comentario;
    }

    //Contrutor vazio
    public Usuario() {}

    //Getters e Setters para pegar e entregar os atributos
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    //To String mostrando todos os atributos
    @Override
    public String toString() {
        return "Usuario{}";
    }
}
