package com.example.aulaxxx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import com.example.aulaxxx.atividade.MainActivity;

public class SplashScreen extends AppCompatActivity {

    private MediaPlayer trooper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //Mapeamento do arquivo .mp3 e start musica
        trooper = MediaPlayer.create(this, R.raw.abertura);
        trooper.start();

        //Oculta a barra de ação do android e configura a activity para tela cheia
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Novo manipulador que contrala o metodo postDeayed para abrir a activity num tempo especifico
        //Declaramos o matodo fiish(), para destruir a splashscreem impossibilitando assim que o usuario
        //Passa retornar com o voltar do device
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getBaseContext(), MainActivity.class));
                finish();
                trooper.stop();
            }
        }, 6000
        );
    }
}