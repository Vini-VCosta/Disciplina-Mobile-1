package com.example.meuslinks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnFace, btnPint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnFace = findViewById(R.id.btnFace);
        btnPint = findViewById(R.id.btnPint);

        btnFace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFace();
            }
        });

        btnPint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPint();
            }
        });
    }
    public void abrirFace(){
        Intent janelaF = new Intent(Intent.ACTION_VIEW, Uri.parse("https://pt-br.facebook.com/"));
        startActivity(janelaF);
    }

    public void abrirPint(){
        Intent janelaP = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.pinterest.jp/"));
        startActivity(janelaP);
    }
}