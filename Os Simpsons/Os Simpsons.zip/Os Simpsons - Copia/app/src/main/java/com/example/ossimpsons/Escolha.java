package com.example.ossimpsons;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Escolha extends AppCompatActivity {

    private TextView resposta;
    private Button btnTeaser, btnLink, btnMapa,btnProximidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);

        resposta = findViewById(R.id.resposta);
        btnTeaser = findViewById(R.id.btnTeaser);
        btnLink = findViewById(R.id.btnLink);
        btnMapa = findViewById(R.id.btnMapa);
        btnProximidade = findViewById(R.id.btnProximidade);

        String recebe = getIntent().getStringExtra("dados");
        resposta.setText(recebe);

        btnTeaser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeaser();
            }
        });

        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLink();
            }
        });

        btnMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMapa();
            }
        });

        btnProximidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProximidade();
            }
        });
    }

        public void abrirTeaser(){
            Intent janelaT = new Intent(this, Teaser.class);
            startActivity(janelaT);
        }

        public void abrirLink(){
            Intent janelaL = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.20thcenturystudios.com/"));
            startActivity(janelaL);
        }

        public void abrirMapa(){
            Intent janelaM = new Intent(this, MapaFox.class);
            startActivity(janelaM);
        }

        public void abrirProximidade(){
            Intent janelaT = new Intent(this, SensorProximidade.class);
            startActivity(janelaT);
        }
    }
